"""What the page can ask the engine to do, beyond drawing a scene.

The command line grew a verb at a time — a table, an error dissection, a
deployment search, a list of named options — and each one was only
reachable from a terminal. This is the same work, started from the page
and reported back as it goes (`yerkon.viewer.jobs`).

Everything here runs against **the settings the page is currently
showing**, not against the shipped defaults. That is the point: somebody
who has spent an afternoon moving figures should be able to ask what
their arrangement costs, where its error comes from, and what it would
take to reach a target — without writing any of it to a file first.
"""

from __future__ import annotations

import math
from typing import Callable, Optional

import pathlib

from yerkon.budget import dissect_all
from yerkon.deliver import deliver as write_study
from yerkon.language import say
from yerkon.numbers import decimal_comma
from yerkon.options import available, read, write
from yerkon.parallel import workers
from yerkon.report import build
from yerkon.scenarios import SITES
from yerkon.settings import Settings
from yerkon.solve import SEARCHABLE, AlreadyMet, Target, search
from yerkon.terms import LABELS, NAMES, REMEDIES
from yerkon.viewer.state import ViewState

#: How a running task reports a line back to the page.
#:
#: Named apart from ``say``, which is the one that turns a name into a
#: sentence. A task builds a line with ``say`` and hands it to ``tell``.
Tell = Callable[[str], None]


def language_of(rows) -> str:
    """Which language a run reports in: the one on screen.

    Every row carries it and the chooser sets all three at once, so the
    first is the one showing (ADR-0035).
    """
    return rows[0][1].language


def deployments_of(rows) -> tuple:
    """The rows as they were prepared, each from its own tab.

    Not from the shipped catalogue. A tab holds an arrangement somebody
    built — anchors dragged, a mast raised, a figure corrected — and a
    run that quietly used the catalogue instead would report a
    deployment nobody was looking at (ADR-0028).
    """
    if not rows:
        raise ValueError("no rows to run")
    return tuple(state.deployed() for _, state in rows)


def settings_of(rows) -> Settings:
    """The figures a run reports against: the first row's.

    The rows share one figure list in practice — the panel edits apply to
    whichever tab is showing and a person moves between them — so this
    takes the first rather than pretending to merge three.
    """
    return rows[0][1].settings()


# --- The table ------------------------------------------------------------


def table(rows) -> Callable:
    """The rows as prepared, run and returned as a table."""

    def work(tell: Tell) -> dict:
        language = language_of(rows)
        chosen = deployments_of(rows)
        tell(say("task.table.running", language, rows=len(chosen),
                 s="" if len(chosen) == 1 else "s", workers=workers()))
        results, table_rows = build(chosen, settings=settings_of(rows))
        tell(say("task.done", language))
        return {
            "columns": [
                "Sistem", "HPE P50", "HPE P95", "VPE P95",
                "Kullanılabilirlik", "Alan km²", "CAPEX/km²", "OPEX/km²/yıl",
            ],
            "rows": [
                {
                    "system": row.system,
                    "cells": [
                        decimal_comma(row.hpe_p50_m, 2),
                        decimal_comma(row.hpe_p95_m, 2),
                        decimal_comma(row.vpe_p95_m, 2),
                        "%" + decimal_comma(100.0 * row.availability, 2),
                        decimal_comma(row.area_km2, 2),
                        decimal_comma(row.capex_tl_per_unit, 0),
                        decimal_comma(row.opex_tl_per_unit_year, 0),
                    ],
                }
                for row in table_rows
            ],
        }

    return work


# --- Where the error came from --------------------------------------------


def budget(rows, sources: Optional[list] = None) -> Callable:
    """Each row's error taken apart, one source at a time (ADR-0020)."""

    def work(tell: Tell) -> dict:
        language = language_of(rows)
        chosen = deployments_of(rows)
        wanted = tuple(sources) if sources else NAMES
        tell(say("task.budget.running", language,
                 runs=len(chosen) * (2 * len(wanted) + 2), rows=len(chosen),
                 s="" if len(chosen) == 1 else "s", sources=len(wanted),
                 workers=workers()))

        dissections = dissect_all(chosen, wanted)
        tell(say("task.done", language))
        return {
            "scenarios": [
                {
                    "name": one.name,
                    "whole_p50_m": decimal_comma(one.whole_p50_m, 2),
                    "whole_p95_m": decimal_comma(one.whole_p95_m, 2),
                    "range_sigma_m": decimal_comma(one.range_sigma_m, 2),
                    "geometry_gain": decimal_comma(one.geometry_gain, 1),
                    "residue_m": decimal_comma(one.residue_p50_m, 2),
                    "quadrature_m": decimal_comma(one.quadrature_p50_m, 2),
                    "dominant": (
                        one.dominant().source if one.dominant() else None
                    ),
                    "sources": [
                        {
                            "source": c.source,
                            "label": LABELS[c.source],
                            "remedy": REMEDIES[c.source],
                            "alone_m": decimal_comma(c.alone_p50_m, 2),
                            "without_m": decimal_comma(c.without_p50_m, 2),
                            "saves_m": decimal_comma(
                                c.saves_m(one.whole_p50_m), 2),
                            # For the bar the page draws. Shares of the
                            # largest, because these do not add to a whole:
                            # errors combine in quadrature and one of them
                            # is a coupling term (ADR-0020).
                            "share": (
                                c.alone_p50_m / one.ranked()[0].alone_p50_m
                                if one.ranked()[0].alone_p50_m > 0 else 0.0
                            ),
                        }
                        for c in one.ranked()
                    ],
                }
                for one in dissections
            ],
        }

    return work


# --- Searching for a deployment -------------------------------------------


def solve(
    state: ViewState,
    scenario: str,
    target: Target,
    over: Optional[dict] = None,
    save_as: Optional[str] = None,
) -> Callable:
    """Search arrangements for the cheapest that meets a target (ADR-0023)."""

    def work(tell: Tell) -> dict:
        language = state.language
        settings = state.settings()
        knobs = over or SEARCHABLE.get(scenario)
        if not knobs:
            raise ValueError(
                "nothing to search for {}. Name the figures to vary.".format(
                    scenario)
            )
        candidates = 1
        for values in knobs.values():
            candidates *= len(values)
        tell(say("task.solve.searching", language, candidates=candidates,
                 scenario=scenario, target=target.describe(language),
                 workers=workers()))

        seen = [0]

        def note(outcome) -> None:
            seen[0] += 1
            tell(say(
                "task.solve.candidate", language,
                seen=seen[0], candidates=candidates, anchors=outcome.anchors,
                availability="%" + decimal_comma(
                    100.0 * outcome.availability, 1),
                hpe_p50=decimal_comma(outcome.hpe_p50_m, 2),
                capex=decimal_comma(outcome.capex_tl, 0),
                meets=say("task.solve.meets", language)
                if target.met_by(outcome) else "",
            ))

        found = search(scenario, target, over, settings, watching=note,
                       language=language)
        best = found.best
        if best is None:
            tell(say("task.solve.none_met", language))
            return {
                "met": False,
                "tried": len(found.tried),
                "closest": decimal_comma(
                    100.0 * max(o.availability for o in found.tried), 2),
            }

        tell(say("task.solve.met", language, met=len(found.met),
                 tried=len(found.tried)))
        outcome = {
            "met": True,
            "tried": len(found.tried),
            "meeting": len(found.met),
            "anchors": best.anchors,
            "availability": "%" + decimal_comma(100.0 * best.availability, 2),
            "hpe_p50_m": decimal_comma(best.hpe_p50_m, 2),
            "hpe_p95_m": decimal_comma(best.hpe_p95_m, 2),
            "capex_tl": decimal_comma(best.capex_tl, 0),
            "fixes_per_second": decimal_comma(best.fixes_per_second, 2),
            "values": {
                key: value for key, value in sorted(best.values.items())
            },
            "moves": [
                {
                    "key": key,
                    "from": decimal_comma(settings.number(key), 2),
                    "to": decimal_comma(value, 2),
                }
                for key, value in sorted(best.values.items())
                if abs(value - settings.number(key)) > 1e-9
            ],
        }

        if save_as:
            try:
                path = write(found.as_option(save_as, settings))
                outcome["saved"] = save_as
                tell(say("task.solve.saved", language, name=path.name))
            except AlreadyMet as nothing_to_do:
                outcome["already_met"] = str(nothing_to_do)
                tell(str(nothing_to_do))
        return outcome

    return work


# --- Placing anchors where the ground is already high ---------------------


def place(state: ViewState, aim: str = "better") -> Callable:
    """Search existing high places for this row's anchors (ADR-0081).

    Hands back the search's own count and the change that puts its
    answer on screen. The change goes through the panel like any other
    edit, and the simulation is what judges it.
    """
    from yerkon.placement import SIZING, mix, search as placed_by_search

    def work(tell: Tell) -> dict:
        language = state.language
        site = state.measured()
        if site is None:
            raise ValueError(say("task.place.needs_ground", language))
        settings = state.settings()
        deployed = state.deployed()
        row = state.scenario

        def kinds(counted: dict) -> str:
            return ", ".join(
                "{} {}".format(n, say("place.origin." + origin, language))
                for origin, n in counted.items())

        last = [0]

        def progress(share: float) -> None:
            tenth = int(share * 10)
            if tenth > last[0]:
                last[0] = tenth
                tell(say("task.place.progress", language,
                         share=decimal_comma(100.0 * share, 0)))

        from yerkon.placement import candidates, demand_cells

        found, _ = candidates(deployed, site, row, settings)
        counted: dict = {}
        for one in found:
            counted[one.origin] = counted.get(one.origin, 0) + 1
        tell(say("task.place.searching", language, scenario=row,
                 candidates=len(found), kinds=kinds(counted),
                 cells=len(demand_cells(deployed, SIZING[row]["cell_m"])),
                 workers=workers()))
        answer = placed_by_search(deployed, site, row, aim, settings,
                        watching=progress)
        chose = mix(answer.problem, answer.chosen)
        tell(say(
            "task.place.chose", language, anchors=len(answer.chosen),
            kinds=kinds(chose),
            share=decimal_comma(100.0 * answer.share, 1),
            grid_share=decimal_comma(100.0 * answer.grid_share, 1),
            cost=decimal_comma(answer.lifecycle_tl, 0),
            grid_cost=decimal_comma(answer.grid_lifecycle_tl, 0),
        ))
        return {
            "aim": aim,
            "anchors": len(answer.chosen),
            "grid_anchors": len(answer.problem.grid),
            "share": decimal_comma(100.0 * answer.share, 1),
            "grid_share": decimal_comma(100.0 * answer.grid_share, 1),
            "lifecycle_tl": decimal_comma(answer.lifecycle_tl, 0),
            "grid_lifecycle_tl": decimal_comma(answer.grid_lifecycle_tl, 0),
            "mix": {say("place.origin." + origin, language): n
                    for origin, n in chose.items()},
            "changes": placed_run(state, answer),
        }

    return work


def placed_run(state: ViewState, answer) -> dict:
    """The edit that replaces this row's anchors with the search's answer.

    One run on the `placed` method, carrying each anchor with the
    structure it stands on, named by this page's own mounting keys.
    Anchors moved or removed by hand belonged to the old runs, so they
    go with them.
    """
    mounting_of, radio_of = state.catalogues()

    def key_of(mounting) -> str:
        for key, option in mounting_of.items():
            if option.kind == mounting.kind:
                return key
        # A column at a signalised junction is a column (ADR-0077).
        for key, option in mounting_of.items():
            if mounting.kind.startswith(option.kind):
                return key
        raise ValueError("no mounting on this page is a {!r}".format(
            mounting.kind))

    first = state.runs[0] if state.runs else None
    spots = [
        (round(anchor.ground_position_m[0], 1),
         round(anchor.ground_position_m[1], 1), key_of(anchor.mounting))
        for anchor in (answer.problem.candidates[i].anchor
                       for i in answer.chosen)
    ]
    run = {
        "identifier": "P",
        "radio": first.radio if first else "sx1280",
        "mounting": first.mounting if first else "column",
        "from_m": 0.0,
        "to_m": state.corridor_m,
        "spacing_m": first.spacing_m if first else 500.0,
        "offset_m": 0.0,
        "method": "placed",
        "spots": spots,
    }
    return {"runs": [run], "moved": {}, "removed": []}


def target_from(payload: dict) -> Target:
    """A target from what the page sent, treating a blank field as no bar."""

    def bar(name: str, default: float) -> float:
        given = payload.get(name)
        if given in (None, ""):
            return default
        return float(given)

    return Target(
        availability=bar("availability", 0.0),
        hpe_p50_m=bar("hpe_p50_m", math.inf),
        hpe_p95_m=bar("hpe_p95_m", math.inf),
        fixes_per_second=bar("fixes_per_second", 0.0),
    )


# --- Writing the study out ------------------------------------------------


def deliver(rows, into: str, with_budget: bool = True) -> Callable:
    """Write the study out as Markdown, from the rows as prepared."""

    def work(tell: Tell) -> dict:
        chosen = deployments_of(rows)
        written = write_study(
            into or "docs/teslim", chosen, settings_of(rows),
            with_budget=with_budget, tell=tell, language=language_of(rows),
        )
        return {
            "into": str(pathlib.Path(into or "docs/teslim").resolve()),
            "files": [
                {"name": one.path.name, "about": one.about} for one in written
            ],
        }

    return work


# --- Bringing in new ground -----------------------------------------------


def fetch(state: ViewState, payload: dict) -> Callable:
    """Fetch real ground for anywhere, from the page.

    The only thing in this project that touches the network, and it was
    the one thing the page could not do — so using anywhere but the four
    Ankara sites meant dropping to a terminal, which for a viewer that is
    meant to be the main way in is a hole (ADR-0008, ADR-0024).

    Writes into the package's own site folder, so what it fetches shows
    up in the ground selector immediately and is committed with
    everything else.
    """

    def work(tell: Tell) -> dict:
        from yerkon.site.cache import SiteCache
        from yerkon.site.fetch import (
            AERIAL_CREDIT,
            AERIAL_NAME_SHOWN,
            AERIAL_TILES,
            DEFAULT_ZOOM,
            PAGE_MOST_TILES,
            CopernicusElevation,
            OpenStreetMapBuildings,
            OpenStreetMapRoads,
            OvertureBuildings,
            OvertureFurniture,
            OvertureRoads,
            TerrainTileElevation,
            TileImagery,
            better_with,
            build_site,
            fitted_zoom,
            tile_of,
        )
        from yerkon.site.http import IN_A_BROWSER
        from yerkon.site.model import (
            BoundingBox, Drape, box_around, read_point)

        name = str(payload.get("name", "")).strip()
        if not name or not name.replace("-", "").replace("_", "").isalnum():
            raise ValueError(
                "a site needs a name of letters, digits, dashes or "
                "underscores; got {!r}".format(name)
            )

        # A centre and a size, because that is what somebody reading a
        # map has: a pin and a sense of how much ground around it. Four
        # edges still work for a box somebody already holds, and the
        # arithmetic lives in one place rather than once here and once in
        # the page.
        corners = ("south", "west", "north", "east")
        if all(payload.get(corner) is not None for corner in corners):
            bounds = BoundingBox(
                south=float(payload["south"]), west=float(payload["west"]),
                north=float(payload["north"]), east=float(payload["east"]),
            )
        else:
            # `read_point` refuses an empty or unreadable centre with a
            # sentence. It used to fall through to the four corners, which
            # the page stopped sending when it started asking for a centre
            # — so pressing Fetch with the box empty raised KeyError in a
            # background thread and the page showed nothing useful.
            latitude, longitude = read_point(payload.get("centre"),
                                             state.language)
            bounds = box_around(latitude, longitude,
                                float(payload.get("size_km") or 3.0))
        spacing = float(payload.get("spacing_m") or 30.0)
        want_buildings = bool(payload.get("buildings", True))

        # The photograph, where the box is ticked. The page names no tile
        # server any more: the project owner chose one, so nobody has to
        # find and paste an address (ADR-0086). An address sent by hand
        # still wins, for whoever drives the page from a script.
        #
        # The owner's provider is not downloaded here at all: the site
        # records which of its tiles cover the box and the page stitches
        # them, since a browser decodes JPEG and a plain install has no
        # image library (ADR-0087).
        tiles = str(payload.get("imagery_url", "")).strip()
        zoom = fitted_zoom(bounds, int(payload.get("imagery_zoom")
                                       or DEFAULT_ZOOM), PAGE_MOST_TILES)
        drape = None
        if not tiles and payload.get("imagery"):
            west_x, north_y = tile_of(bounds.north, bounds.west, zoom)
            east_x, south_y = tile_of(bounds.south, bounds.east, zoom)
            drape = Drape(
                template=AERIAL_TILES, zoom=zoom,
                west_x=west_x, north_y=north_y,
                east_x=east_x, south_y=south_y,
                source="{} z{} ({})".format(AERIAL_NAME_SHOWN, zoom,
                                           AERIAL_CREDIT))
        imagery = TileImagery(
            url_template=tiles, zoom=zoom,
            cache_directory=str(SITES / "_tiles"),
        ) if tiles else None

        # What each place can reach. The published site's worker reads
        # no GeoTIFF and no GeoParquet and cannot ask the Copernicus
        # bucket, which does not answer other pages; terrain tiles and
        # Overpass both do (ADR-0086). A desktop tries the better
        # source first and falls back to the same two.
        cache = str(SITES / "_tiles")
        if IN_A_BROWSER:
            ground = (TerrainTileElevation(cache_directory=cache),)
            built = (OpenStreetMapBuildings(),)
            driven = (OpenStreetMapRoads(),)
            standing = ()
        else:
            # The better sources only where this install can read them,
            # so a plain install's record says what happened rather than
            # what to install (ADR-0087).
            short = set(better_with())
            copernicus = "rasterio" not in short and "requests" not in short
            overture = "pyarrow" not in short and "requests" not in short
            ground = ((CopernicusElevation(cache_directory=cache),)
                      if copernicus else ()) + (
                TerrainTileElevation(cache_directory=cache),)
            built = ((OvertureBuildings(cache_directory=cache),)
                     if overture else ()) + (OpenStreetMapBuildings(),)
            driven = ((OvertureRoads(cache_directory=cache),)
                      if overture else ()) + (OpenStreetMapRoads(),)
            standing = ((OvertureFurniture(cache_directory=cache),)
                        if overture else ())

        tell(say("task.fetch.fetching", state.language,
                 south=decimal_comma(bounds.south, 4),
                 west=decimal_comma(bounds.west, 4),
                 north=decimal_comma(bounds.north, 4),
                 east=decimal_comma(bounds.east, 4),
                 spacing_m=decimal_comma(spacing, 0)))
        tell(say("task.fetch.slow", state.language))

        site = build_site(
            bounds,
            spacing_m=spacing,
            elevation_sources=ground,
            buildings_sources=built if want_buildings else (),
            # Roads come with the buildings: they are the same fetch by
            # the same road, and without them a receiver cannot drive the
            # real road and a search has no structure to bolt on to
            # (ADR-0045, ADR-0046).
            roads_sources=driven if want_buildings else (),
            furniture_sources=standing if want_buildings else (),
            imagery_source=imagery,
        )
        if drape is not None:
            from dataclasses import replace

            site = replace(site, drape=drape, manifest=replace(
                site.manifest,
                notes=site.manifest.notes + (drape.source,)))
        SiteCache(SITES / name).save(site)

        tell(say("task.fetch.got", state.language,
                 width_m=decimal_comma(site.width_m, 0),
                 height_m=decimal_comma(site.height_m, 0),
                 relief_m=decimal_comma(site.relief_m, 0),
                 roughness_m=decimal_comma(site.roughness_m(), 2)))
        for note in site.manifest.notes:
            tell(note)

        return {
            "name": name,
            "describe": site.manifest.describe(),
            "width_m": round(site.width_m),
            "height_m": round(site.height_m),
            "relief_m": round(site.relief_m, 1),
            "roughness_m": round(site.roughness_m(), 2),
            "buildings": site.manifest.building_count,
            "aerial": site.aerial is not None or site.drape is not None,
            "roads": len(site.roads_m),
            "furniture": 0 if site.furniture is None else len(site.furniture),
            "notes": list(site.manifest.notes),
        }

    return work


# --- Named options --------------------------------------------------------


def _shown(value) -> str:
    """A figure as the page reads it. Not every one is a quantity.

    Which ground a row stands on is a name (ADR-0027), and asking
    `decimal_comma` for one took the whole options panel down with a 400
    — so the page showed no options at all rather than one bad row.
    """
    if isinstance(value, str):
        return value or "-"
    return decimal_comma(value, 2)


def listed(settings: Settings) -> dict:
    """Every option on hand, and what each would move from where it is now."""
    out = []
    for name in available():
        option = read(name)
        out.append({
            "name": option.name,
            "title": option.title,
            "note": option.note,
            "origin": option.origin,
            "moves": [
                {
                    "key": key,
                    "from": _shown(was),
                    "to": _shown(now),
                }
                for key, was, now in option.differences(settings)
            ],
        })
    return {"options": out, "searchable": {
        name: {key: list(values) for key, values in knobs.items()}
        for name, knobs in SEARCHABLE.items()
    }}
