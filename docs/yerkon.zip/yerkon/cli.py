"""Command line entry points.

``fetch`` is the only thing that touches the network; it writes a cache,
and everything else reads that cache and runs offline. ADR-0008 is why
they are separate.

``table`` runs the three scenarios and prints the four rows of the
report's comparison table.

``view`` starts a local site: what YERKON is, what this project
measured and what it left out, the published table, and behind them the
same engine drawn in three dimensions with every setting live.

``pages`` writes that site out as a folder of files, without the
simulator, for anywhere that serves files and runs nothing.

``defaults`` lists every figure the model needs that nobody supplied,
what it affects, and what replacing it would move.

``budget`` takes each scenario's error apart, one source at a time, and
says which one is worth spending money on.

``options`` lists the named deployment options on hand, and every other
verb takes ``--option`` to run against one.

``solve`` searches deployment arrangements for the cheapest that meets a
target, and saves the winner as a new option.

``deliver`` writes the whole study out as Markdown: the table, the
error budget, the figures and what they rest on, and the options.

``calibrate`` reads what a MATLAB run measured and says what to put in
the defaults file.

``site`` searches for the cheapest deployment that meets a target.

``design`` shows what a set of settings implies, and asks once before
changing them. The panel it prints is built in ``proposal`` and rendered
unchanged by the application too, so both front ends ask the same
question in the same words. See ADR-0001 and ADR-0009.
"""

from __future__ import annotations

import argparse
import pathlib
import sys

from yerkon.site.cache import SiteCache
from yerkon.site.fetch import (
    DEFAULT_ZOOM,
    CopernicusElevation,
    GeoTiffElevation,
    OpenStreetMapBuildings,
    OvertureBuildings,
    OvertureFurniture,
    OvertureRoads,
    ServiceElevation,
    TileImagery,
    Unreachable,
    build_site,
)
from yerkon.design import (
    ANTENNA_CHOICES,
    Design,
    MOUNTING_CHOICES,
    RADIO_CHOICES,
    REGION_CHOICES,
    chosen,
    derive,
)
from yerkon.numbers import decimal_comma, readable
from yerkon.parallel import workers
from yerkon.report import (
    as_breakdown,
    as_markdown,
    as_text,
    build,
    coarsely_read,
    footnotes,
)
from yerkon.scenarios import (
    CHOICES as SCENARIO_CHOICES,
    SITES,
    fetched,
)
from yerkon.viewer.state import fetched_sites
from yerkon.proposal import OUTCOME_LABELS, confirm, show_outcome
from yerkon.terms import NAMES as SOURCE_NAMES
from yerkon.site.model import BoundingBox, box_around, read_point


#: Grid points past which a fetch is worth warning about rather than
#: just doing. Four thousand a side; the shipped sites are a tenth of it.
BIG_GRID = 16_000_000


def _site_directory(into: str) -> pathlib.Path:
    """Where `--into` writes.

    A bare name goes into the package's own site folder, which is the one
    place `fetched()` and the viewer's ground picker look. Writing a
    fetch somewhere they cannot see it is the mistake this exists to stop:
    the fetch reports success and the site never appears.

    Anything with a separator is a path and is honoured as one, so a
    scratch directory outside the package still works.
    """
    if "/" in into or "\\" in into or pathlib.Path(into).is_absolute():
        return pathlib.Path(into)
    return SITES / into


def _box_from(args) -> BoundingBox:
    """The area to fetch, from a centre and a size or from four edges.

    Centre and size first, because that is what somebody reading a map
    has: a pin and a sense of how much around it. Four edges stay, for a
    box somebody already holds.
    """
    corners = (args.south, args.west, args.north, args.east)
    if args.centre is not None or args.size is not None:
        if any(corner is not None for corner in corners):
            raise ValueError(
                "give either --centre with --size, or the four edges. Both "
                "together describe two different boxes."
            )
        if args.centre is None or args.size is None:
            raise ValueError("--centre needs --size, and --size needs --centre")
        latitude, longitude = read_point(args.centre)
        if args.size <= 0.0:
            raise ValueError("--size is in kilometres across, so it is positive")
        return box_around(latitude, longitude, args.size)

    if any(corner is None for corner in corners):
        raise ValueError(
            "give --centre with --size, or all four of --south --west "
            "--north --east"
        )
    return BoundingBox(
        south=args.south, west=args.west, north=args.north, east=args.east
    )


def fetch(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yerkon fetch",
        description=(
            "Download ground and buildings for an area into a cache. This is "
            "the only command that uses the network; runs read the cache."
        ),
    )
    parser.add_argument(
        "--centre", metavar="LAT,LON",
        help=(
            "middle of the area, as you would read it off a map: "
            "--centre 37.8716,32.4847. Use with --size."
        ),
    )
    parser.add_argument(
        "--size", type=float, metavar="KM",
        help="how many kilometres across, centred on --centre (square)",
    )
    parser.add_argument("--south", type=float)
    parser.add_argument("--west", type=float)
    parser.add_argument("--north", type=float)
    parser.add_argument("--east", type=float)
    parser.add_argument(
        "--into", required=True,
        help=(
            "where to write it. A bare name like `konya` goes into the "
            "package's own site folder, which is where the viewer looks; "
            "anything with a separator is taken as a path."
        ),
    )
    parser.add_argument(
        "--spacing", type=float, default=30.0,
        help="grid spacing in metres (default: %(default)s)",
    )
    parser.add_argument(
        "--geotiff",
        help=(
            "a downloaded elevation raster to prefer over the online "
            "service. Faster, higher resolution, and it needs no network."
        ),
    )
    parser.add_argument(
        "--no-buildings", action="store_true",
        help="skip OpenStreetMap; the site records that nobody looked",
    )
    parser.add_argument(
        "--no-roads", action="store_true",
        help=(
            "skip road geometry and roadside structures. Without them a "
            "receiver cannot drive the real road and the placement "
            "searches have no existing structures to bolt an anchor to."
        ),
    )
    parser.add_argument(
        "--no-copernicus", action="store_true",
        help="skip the Copernicus tiles, leaving only the query service",
    )
    parser.add_argument(
        "--tile-cache", default="sites/_tiles",
        help="where Copernicus tiles are kept (default: %(default)s)",
    )
    parser.add_argument(
        "--imagery",
        help=(
            "a slippy-map tile address like "
            "'https://example/{z}/{x}/{y}.png', to drape an aerial "
            "photograph over the ground in the viewer. Nothing in the "
            "simulation reads it. No address is shipped: every provider "
            "has its own terms, and the terms you accept are yours."
        ),
    )
    parser.add_argument(
        "--imagery-zoom", type=int, default=DEFAULT_ZOOM,
        help=(
            "tile zoom for --imagery (default: %(default)s, about "
            "0.9 m per pixel in Ankara)"
        ),
    )
    args = parser.parse_args(argv)

    try:
        bounds = _box_from(args)
    except ValueError as error:
        print(error, file=sys.stderr)
        return 2

    into = _site_directory(args.into)

    sources = []
    if args.geotiff:
        sources.append(GeoTiffElevation(args.geotiff))
    if not args.no_copernicus:
        sources.append(CopernicusElevation(cache_directory=args.tile_cache))
    sources.append(ServiceElevation())

    per_lat, per_lon = bounds.metres_per_degree()
    across_km = (bounds.east - bounds.west) * per_lon / 1000.0
    along_km = (bounds.north - bounds.south) * per_lat / 1000.0
    nodes = int(across_km * 1000 / args.spacing) * int(along_km * 1000 / args.spacing)

    print("Fetching {:.4f},{:.4f} to {:.4f},{:.4f} at {:.0f} m".format(
        bounds.south, bounds.west, bounds.north, bounds.east, args.spacing
    ))
    print("  {:.1f} x {:.1f} km, {:,} grid points".format(
        across_km, along_km, nodes))
    # A grid this size is minutes of sampling and a site file nobody
    # wants, and the usual cause is a spacing left at 30 m over a region
    # rather than a town. Said before the work rather than after it.
    if nodes > BIG_GRID:
        print("  that is a large grid. {:.0f} m spacing would make it "
              "{:,} points.".format(
                  args.spacing * 4,
                  int(across_km * 1000 / (args.spacing * 4))
                  * int(along_km * 1000 / (args.spacing * 4))),
              file=sys.stderr)
    print("  ground: {} (each tried in turn until one answers)".format(
        ", then ".join(source.name for source in sources)
    ))
    if not args.no_buildings:
        print("  features: Overture Maps, then OpenStreetMap (each tried "
              "in turn until one answers)")
    if not args.no_roads:
        print("  roads and roadside structures: Overture Maps")
    if args.imagery:
        print("  photograph: {} at zoom {}".format(
            args.imagery, args.imagery_zoom))

    # What the query service would cost, and only when it is the source
    # that will actually be asked. A GeoTIFF or a Copernicus tile answers
    # first and makes no calls at all, so quoting a rate limit ahead of
    # them describes a fetch that is not going to happen.
    if isinstance(sources[0], ServiceElevation):
        service = sources[0]
        points = service.points_required(bounds, args.spacing)
        calls = (points + service.batch - 1) // service.batch
        minutes = calls * service.seconds_between_requests / 60.0
        print("  {:,} points, {:,} calls, about {:.0f} minutes at the "
              "service's rate limit".format(points, calls, minutes))

    try:
        site = build_site(
            bounds,
            spacing_m=args.spacing,
            elevation_sources=tuple(sources),
            buildings_sources=() if args.no_buildings else (
                OvertureBuildings(cache_directory=str(SITES / "_tiles")),
                OpenStreetMapBuildings(),
            ),
            roads_sources=() if args.no_roads else (
                OvertureRoads(cache_directory=str(SITES / "_tiles")),
            ),
            furniture_sources=() if args.no_roads else (
                OvertureFurniture(cache_directory=str(SITES / "_tiles")),
            ),
            imagery_source=TileImagery(
                url_template=args.imagery,
                zoom=args.imagery_zoom,
                cache_directory=args.tile_cache,
            ) if args.imagery else None,
        )
    except Unreachable as error:
        print("\nNothing answered.\n  {}".format(error), file=sys.stderr)
        print(
            "\nEither pass --geotiff with a downloaded raster, or run this "
            "from a machine that can reach the elevation service.",
            file=sys.stderr,
        )
        return 1

    SiteCache(into).save(site)

    print("\nWrote {}".format(into))
    print("  {}".format(site.manifest.describe()))
    print("  {:.0f} x {:.0f} m, relief {:.0f} m, roughness {:.2f} m".format(
        site.width_m, site.height_m, site.relief_m, site.roughness_m()
    ))
    for note in site.manifest.notes:
        print("  note: {}".format(note))

    # A fetch on its own is ground nobody has asked anything of. These
    # are the two steps between it and a row of the table, named rather
    # than left to be found.
    name = pathlib.Path(into).name
    if _site_directory(name) == pathlib.Path(into):
        from yerkon.settings import DEFAULT_FILE

        print("\nTo get findings out of it:")
        print("  yerkon view   then step 1 Ground -> {}, then step 6 Run"
              .format(name))
        print("  or: copy {}, set one of urban.site / rural.site / "
              "tunnel.site to \"{}\", and".format(DEFAULT_FILE, name))
        print("      yerkon table --defaults <that file>")
        print("\nA row standing on it is brought inside these {:.1f} x "
              "{:.1f} km, because that is as far as the fetch reached "
              "(ADR-0037).".format(
                  site.width_m / 1000.0, site.height_m / 1000.0))
    else:
        print("\nWritten outside the package's site folder, so the viewer "
              "will not list it. Pass a bare name like `--into {}` to put "
              "it where the ground picker looks.".format(name))
    return 0


EDITS = {
    "region": (REGION_CHOICES, "region"),
    "radio": (RADIO_CHOICES, "radio"),
    "mounting": (MOUNTING_CHOICES, "mounting"),
    "antenna": (ANTENNA_CHOICES, "antenna"),
}

#: Which Design field each command line option sets.
EDIT_FIELDS = {
    "region": "region",
    "radio": "anchor_radio",
    "mounting": "mounting",
    "antenna": "antenna",
    "receiver_height": "receiver_height_m",
    "roughness": "surface_roughness_m",
    "tolerance": "target_ranging_sigma_m",
}


def design(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yerkon design",
        description=(
            "Show what a set of settings implies. Given an edit, show "
            "everything it would change and ask once before applying it."
        ),
    )
    for option, (catalogue, what) in EDITS.items():
        parser.add_argument(
            "--{}".format(option),
            help="{}: {}".format(what, ", ".join(sorted(catalogue))),
        )
    parser.add_argument("--receiver-height", type=float, help="metres above ground")
    parser.add_argument(
        "--roughness", type=float,
        help="root-mean-square height of the reflecting ground, in metres",
    )
    parser.add_argument(
        "--tolerance", type=float,
        help="ranging error a link may have and still count as usable, in metres",
    )
    parser.add_argument(
        "--yes", action="store_true",
        help="answer the confirmation yes without asking",
    )
    args = parser.parse_args(argv)

    current = Design()
    edits = {}
    for option, field in EDIT_FIELDS.items():
        value = getattr(args, option.replace("-", "_"))
        if value is None:
            continue
        if option in EDITS:
            catalogue, what = EDITS[option]
            try:
                value = chosen(catalogue, value, what)
            except ValueError as error:
                print(error, file=sys.stderr)
                return 2
        edits[field] = value

    if not edits:
        print(describe_outcome(current))
        return 0

    def ask(panel: str) -> bool:
        print(panel)
        if args.yes:
            print("\nApplying (--yes).")
            return True
        answer = input("\nApply all of that? [y/N] ").strip().lower()
        return answer in {"y", "yes"}

    try:
        updated, applied = confirm(current, ask, **edits)
    except ValueError as error:
        print(error, file=sys.stderr)
        return 2

    if not applied:
        print("\nNothing changed.")
        return 0

    print()
    print(describe_outcome(updated))
    return 0


def describe_outcome(design_: Design) -> str:
    """The settings and what they imply, in the panel's own words."""
    outcome = derive(design_)
    lines = ["Settings:"]
    lines.append("  region             {}".format(design_.region.region))
    lines.append("  anchor radio       {}".format(design_.anchor_radio.part))
    lines.append("  antenna            {}".format(design_.antenna.part))
    lines.append("  mounting           {}".format(design_.mounting.kind))
    lines.append("  receiver height    {} m".format(
        decimal_comma(design_.receiver_height_m, 2)))
    lines.append("  ground roughness   {} m".format(
        decimal_comma(design_.surface_roughness_m, 2)))
    lines.append("  ranging tolerance  {} m".format(
        decimal_comma(design_.target_ranging_sigma_m, 2)))
    lines.append("")
    lines.append("Which gives:")
    width = max(len(label) for label in OUTCOME_LABELS.values())
    for field, label in OUTCOME_LABELS.items():
        lines.append("  {:<{width}}  {}".format(
            label, show_outcome(field, getattr(outcome, field)), width=width
        ))
    return "\n".join(lines)


def _add_option_flag(parser: argparse.ArgumentParser) -> None:
    from yerkon.options import available

    parser.add_argument(
        "--option", metavar="NAME",
        help=(
            "run against a named deployment option instead of the "
            "defaults. On hand: {}. See `yerkon options`.".format(
                ", ".join(available()) or "none"
            )
        ),
    )


def _add_defaults_flag(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--defaults", metavar="FILE",
        help=(
            "a settings file of the figures nobody supplied. Everything "
            "is rebuilt from it: mounting costs and heights, the "
            "unpublished radio figures, the clocks, and the operating "
            "rates. See `yerkon defaults`."
        ),
    )
    parser.add_argument(
        "--fast", action="store_true",
        help=(
            "read the ground coarsely and draw the shadows once, for "
            "trying things: about a minute instead of about a quarter "
            "of an hour. The answer is not publishable and every "
            "command that takes this says so beside it."
        ),
    )


def _settings_from(args):
    """The settings a run should use: a file, an option, both, or neither.

    An option is a short list of edits, so it applies over whatever file
    is in play rather than replacing it. That way `--defaults` holding
    somebody's real quotations and `--option rural-dense` holding a
    denser grid compose, instead of one silently discarding the other.
    """
    from yerkon.options import settings_for
    from yerkon.settings import hurried, load

    settings = load(args.defaults) if args.defaults else None
    name = getattr(args, "option", None)
    if name:
        settings = settings_for(name, settings)
    # Last, so it wins over a file or an option that set these: asking
    # for speed and being given a quarter of an hour anyway is the one
    # thing this flag must not do.
    if getattr(args, "fast", False):
        settings = hurried(settings)
    return settings


def table(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yerkon table",
        description=(
            "Run the three scenarios and print the four YERKON rows of the "
            "comparison table, with what they rest on."
        ),
    )
    parser.add_argument(
        "--markdown", action="store_true",
        help="print the table as markdown rather than aligned text",
    )
    parser.add_argument(
        "--only", action="append", choices=sorted(SCENARIO_CHOICES),
        help="run only these scenarios; repeat the flag for several",
    )
    parser.add_argument(
        "--no-notes", action="store_true",
        help="print the table alone, without what it rests on",
    )
    _add_defaults_flag(parser)
    _add_option_flag(parser)
    parser.add_argument(
        "--preset", action="append", metavar="NAME",
        help=(
            "run a saved arrangement instead of the shipped scenario for "
            "its row; repeat the flag for several. Each one's name and a "
            "hash of its contents are printed with the table, because a "
            "row that rests on a file somebody saved has to say which "
            "file and which version of it."
        ),
    )
    parser.add_argument(
        "--presets", default="presets", metavar="DIR",
        help="where saved arrangements are kept (default: %(default)s)",
    )
    parser.add_argument(
        "--publish", nargs="?", const="", metavar="PATH",
        help=(
            "write what this run produced into the published record the "
            "site and the README read, instead of leaving it in the "
            "terminal for somebody to retype. Wants all four rows and "
            "refuses a coarse read."
        ),
    )
    args = parser.parse_args(argv)

    try:
        settings = _settings_from(args)
    except (FileNotFoundError, ValueError) as error:
        print(error, file=sys.stderr)
        return 2

    from yerkon.scenarios import catalogue

    available = catalogue(settings) if settings else SCENARIO_CHOICES
    # The keys travel beside the rows, because a row's own `name` is a
    # sentence in whichever language the run is in — matching a saved
    # arrangement on it would work in Turkish and quietly stop working
    # in English.
    keys = list(args.only) if args.only else list(available)
    chosen = tuple(available[name] for name in keys)

    # A saved arrangement replaces the row it belongs to rather than
    # adding one: the table has four rows and always did, and a preset
    # is a different answer to the same row's question.
    try:
        chosen, arrangements = _with_presets(keys, chosen, args)
    except (ValueError, LookupError) as error:
        print(error, file=sys.stderr)
        return 2

    print("Running {} scenario{}{} on {} processes.".format(
        len(chosen), "" if len(chosen) == 1 else "s",
        " against {}".format(settings.path) if settings else "",
        workers(),
    ), file=sys.stderr)

    try:
        results, rows = build(chosen, settings=settings)
    except ValueError as error:
        print(error, file=sys.stderr)
        return 2
    if args.publish is not None:
        try:
            written = _publish(rows, keys, args, settings)
        except ValueError as error:
            print(error, file=sys.stderr)
            return 2
        print("Published into {}".format(written), file=sys.stderr)
    print(as_markdown(rows) if args.markdown else as_text(rows))
    if not args.no_notes:
        print()
        print(footnotes(results, rows, arrangements))
    else:
        # The notes carry this, and with them turned off it still has to
        # be said: it is about the table above rather than about what
        # the table rests on.
        hurried = coarsely_read(results)
        if hurried:
            print("\n" + hurried, file=sys.stderr)
    return 0


def _publish(rows, keys, args, settings):
    """Write a finished run into the published record.

    The record says which figures the run read and how finely it read
    them, because on a web page a coarse table and a published one look
    the same (ADR-0063, ADR-0064).
    """
    from yerkon.published import write
    from yerkon.settings import DEFAULTS

    settings = settings or DEFAULTS
    source = str(args.defaults) if args.defaults else "defaults.toml"
    if getattr(args, "option", None):
        source += " + {}".format(args.option)
    if getattr(args, "preset", None):
        source += " + {}".format(", ".join(args.preset))
    return write(
        rows=rows,
        keys=tuple(keys),
        source=source,
        shadow_draws=settings.number("site.shadow_draws"),
        profile_spacing_m=settings.number("site.profile_spacing_m"),
        path=args.publish or None,
    )


def _with_presets(keys: list, chosen: tuple, args) -> tuple:
    """Swap in each named arrangement for the row it belongs to.

    The viewer is imported here and nowhere else in this command,
    because turning a stored arrangement back into something the table
    can run is exactly what `ViewState` is for and there is no second
    way to do it that would not be a copy of it.
    """
    if not args.preset:
        return chosen, ()

    from yerkon.presets import PresetStore
    from yerkon.viewer.state import ViewState

    store = PresetStore(args.presets)
    by_name = {}
    used = []
    for name in args.preset:
        preset = store.read(name)
        state = ViewState().merged(preset.state)
        # The row it runs as is the one it was saved from. A preset that
        # names no mode would otherwise land on whichever row happened
        # to be first, which is a silent wrong answer.
        by_name[preset.mode] = state.deployed()
        used.append(preset)

    swapped = [by_name.get(key, row) for key, row in zip(keys, chosen)]
    missing = sorted(set(by_name) - set(keys))
    if missing:
        raise ValueError(
            "this table has no {} row, so the arrangement saved for it has "
            "nothing to replace. Rows here: {}. An arrangement runs as the "
            "row it was saved from.".format(
                ", ".join(missing), ", ".join(keys),
            )
        )
    return tuple(swapped), tuple(used)


def view(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yerkon view",
        description=(
            "Open the site in a browser: what YERKON is, what this "
            "project measured, the published table, and the live 3D "
            "simulator behind it. Everything in the simulator is "
            "configurable and every number comes from the same engine "
            "that builds the table."
        ),
    )
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument(
        "--no-browser", action="store_true",
        help="print the address instead of opening it",
    )
    parser.add_argument(
        "--presets", default=None, metavar="DIR",
        help=(
            "where saved arrangements are kept (default: presets, in the "
            "directory the command is run from)"
        ),
    )
    parser.add_argument(
        "--map-tiles",
        help=(
            "tile address for the place picker's map, as "
            "'{z}/{x}/{y}'. Defaults to OpenStreetMap. Pass an empty "
            "string to draw no map, on a machine with no way out."
        ),
    )
    _add_defaults_flag(parser)
    _add_option_flag(parser)
    args = parser.parse_args(argv)

    try:
        settings = _settings_from(args)
    except (FileNotFoundError, ValueError) as error:
        print(error, file=sys.stderr)
        return 2
    if settings is not None:
        print("Reading figures from {}.".format(settings.path))

    from yerkon.viewer import serve

    try:
        serve(host=args.host, port=args.port, open_browser=not args.no_browser,
              map_tiles=args.map_tiles, presets=args.presets)
    except OSError as error:
        print(
            "Could not listen on {}:{} ({}). Another viewer may already be "
            "running; try --port 8766.".format(args.host, args.port, error),
            file=sys.stderr,
        )
        return 1
    return 0


def pages(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yerkon pages",
        description=(
            "Write the site out as a folder of files, for somewhere that "
            "serves files and runs nothing. The simulator stays behind "
            "because it needs the engine, and a page in its place says "
            "where it is and how to start it."
        ),
    )
    parser.add_argument(
        "--into", default="docs", metavar="DIR",
        help=(
            "where to write them (default: %(default)s, which is the "
            "folder GitHub Pages can serve a branch from)"
        ),
    )
    args = parser.parse_args(argv)

    from yerkon.published import read
    from yerkon.viewer.pages import write_pages

    try:
        record = read()
    except (OSError, ValueError, KeyError) as error:
        # A public site whose results page says "no published run" is
        # worse than no site.
        print(
            "there is no published run to draw: {}. Run `yerkon table "
            "--publish` first.".format(error),
            file=sys.stderr,
        )
        return 2
    written = write_pages(args.into, record)
    print("Wrote {} files into {}/".format(len(written), args.into))
    print("The table on them is the run of {}.".format(record.run_on))
    return 0


def site(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yerkon site",
        description=(
            "Find the least expensive way to meet an accuracy target over "
            "a corridor, using the structures that already stand beside it "
            "and building only where none does."
        ),
    )
    parser.add_argument("--corridor", type=float, default=12_000.0,
                        help="length in metres (default: %(default)s)")
    parser.add_argument("--tolerance", type=float, default=5.0,
                        help="ranging error a link may have, in metres")
    parser.add_argument("--covered", type=float, default=0.95,
                        help="share of the corridor that must have a position")
    parser.add_argument("--relief", type=float, default=91.0,
                        help=(
                            "height of the modelled rolling ground, in "
                            "metres. There is no zero: nowhere is flat, and "
                            "a level plane is the most favourable ground "
                            "this model can draw rather than the neutral "
                            "one (ADR-0021). Ignored when --ground names a "
                            "fetched site."
                        ))
    parser.add_argument("--ground", metavar="NAME",
                        help=(
                            "stand the search on fetched ground instead of "
                            "modelled hills, by site name. The package "
                            "ships Ankara: {}".format(
                                ", ".join(fetched_sites()) or "none fetched"
                            )
                        ))
    parser.add_argument("--radio", default="e28",
                        help="anchor module: {}".format(
                            ", ".join(sorted(RADIO_CHOICES))))
    parser.add_argument("--region", default="TR")
    parser.add_argument("--all", action="store_true",
                        help="list every candidate, not only those that meet")
    _add_defaults_flag(parser)
    _add_option_flag(parser)
    args = parser.parse_args(argv)

    from yerkon.evaluate import Journey, Receiver
    from yerkon.hardware import DWM3000, SX1280
    from yerkon.siting import Requirement, cheapest
    from yerkon.world import (
        Road, graded_alignment, rolling_terrain, terrain_from_site,
    )

    from yerkon.cost import operating_rates
    from yerkon.hardware import radios as radio_catalogue
    from yerkon.world import mountings

    try:
        settings = _settings_from(args)
        catalogue_of_radios = (
            radio_catalogue(settings) if settings else RADIO_CHOICES
        )
        radio = chosen(catalogue_of_radios, args.radio, "radio")
        region = chosen(REGION_CHOICES, args.region, "region")
        requirement = Requirement(
            target_sigma_m=args.tolerance, corridor_covered=args.covered
        )
    except (FileNotFoundError, ValueError) as error:
        print(error, file=sys.stderr)
        return 2

    if args.ground:
        site = fetched(args.ground)
        if site is None:
            print("no site fetched called {}. There is: {}".format(
                args.ground, ", ".join(fetched_sites()) or "nothing",
            ), file=sys.stderr)
            return 2
        terrain = terrain_from_site(site)
    else:
        # Never a plane. A level surface hands every reflection the
        # specular angle the two-ray term assumes, which would make the
        # search recommend structures that only work on ground nobody
        # will ever build on (ADR-0021).
        terrain = rolling_terrain(
            amplitude_m=max(args.relief, 1.0), wavelength_m=3000.0,
            micro_roughness_m=0.2,
        )
    centreline = [
        (float(x), 0.0)
        for x in range(0, int(args.corridor) + 1, 500)
    ]
    road = Road(centreline_m=centreline, terrain=terrain,
                surface_m=graded_alignment(centreline, terrain))
    units = (
        Receiver("araç", Journey(road=road, speed_m_s=27.8, duration_s=300.0),
                 radios=(SX1280, DWM3000)),
    )

    print("Searching {:.1f} km at a {:.1f} m tolerance, {:.0f}% covered."
          .format(args.corridor / 1000.0, args.tolerance, args.covered * 100),
          file=sys.stderr)

    from yerkon.siting import Availability, TYPICAL_ROADSIDE

    if settings:
        # Rebuild what stands beside the road from the same file, so a
        # run against real site costs searches over real structures.
        rebuilt = mountings(settings)
        by_kind = {option.kind: option for option in rebuilt.values()}
        available = tuple(
            Availability(
                by_kind.get(entry.mounting.kind, entry.mounting),
                entry.every_m, entry.from_m, entry.to_m,
            )
            for entry in TYPICAL_ROADSIDE
        )
        rates = operating_rates(settings)
    else:
        available = TYPICAL_ROADSIDE
        rates = None

    winner, everything = cheapest(
        terrain, args.corridor, units, radio=radio,
        requirement=requirement, region=region,
        available=available,
        **({"rates": rates} if rates else {}),
    )

    shown = everything if args.all else tuple(c for c in everything if c.meets)
    print("{:<34}{:>8}{:>15}{:>10}".format(
        "candidate", "anchors", "CAPEX [TL]", "covered"))
    print("-" * 67)
    for candidate in shown:
        print("{:<34}{:>8}{:>15}{:>10}  {}".format(
            candidate.label,
            len(candidate.anchors),
            decimal_comma(candidate.costing.capex_tl, 0),
            "%" + decimal_comma(100.0 * candidate.corridor_covered, 1),
            "" if candidate.meets else "(short)",
        ))

    if winner is None:
        print("\nNothing on offer meets that. Loosen the tolerance, accept "
              "less of the corridor, or allow taller structures.",
              file=sys.stderr)
        return 1

    counted: dict = {}
    for anchor in winner.anchors:
        counted[anchor.mounting.kind] = counted.get(anchor.mounting.kind, 0) + 1

    print("\nCheapest that meets it: {}".format(winner.label))
    for kind, count in sorted(counted.items()):
        print("  {} x {}".format(count, kind))
    print("  {} TL to build, {} TL a year to run".format(
        decimal_comma(winner.costing.capex_tl, 0),
        decimal_comma(winner.costing.opex_tl_per_year, 0)))
    print("  {} km² served, {} TL per km², {} TL per route kilometre".format(
        decimal_comma(winner.served_km2, 2),
        decimal_comma(winner.costing.capex_tl_per_km2, 0),
        decimal_comma(winner.costing.capex_tl_per_route_km, 0)))
    print("  {} of that rests on rates nobody supplied.".format(
        "%" + decimal_comma(100.0 * winner.costing.assumed_share, 0)))
    return 0


def defaults(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yerkon defaults",
        description=(
            "Every figure this project needs that the report did not "
            "supply, in one list, with what each affects. Replacing one "
            "is an edit to defaults.toml, not a change to the code."
        ),
    )
    parser.add_argument(
        "--file", help="a settings file to read instead of the shipped one"
    )
    parser.add_argument(
        "--sourced", action="store_true",
        help="list the figures that have been sourced instead",
    )
    parser.add_argument(
        "--full", action="store_true",
        help="print each figure's note and sensitivity too",
    )
    args = parser.parse_args(argv)

    from yerkon.settings import DEFAULT_FILE, load

    try:
        settings = load(args.file)
    except (FileNotFoundError, ValueError) as error:
        print(error, file=sys.stderr)
        return 2

    listed = settings.sourced_entries if args.sourced else settings.assumed
    heading = "Sourced" if args.sourced else "Still assumed"

    print("{} in {}".format(heading, settings.path))
    print("{} of {} figures are still assumptions ({}).".format(
        len(settings.assumed), len(settings.entries),
        "%" + decimal_comma(100.0 * settings.assumed_share, 0),
    ))
    print()

    if not listed:
        print("  none.")
        return 0

    width = max(len(entry.key) for entry in listed)
    for entry in listed:
        print("{key:<{width}}  {value:>12} {unit}".format(
            key=entry.key, width=width,
            value=readable(float(entry.sourced.value)),
            unit=entry.sourced.unit,
        ))
        print("{:<{width}}  affects: {}".format("", entry.affects, width=width))
        if args.full:
            print("{:<{width}}  {}".format("", entry.sourced.note, width=width))
            if entry.sensitivity:
                print("{:<{width}}  sensitivity: {}".format(
                    "", entry.sensitivity, width=width))
        print()

    if not args.sourced:
        print("To replace one: copy {}, edit the value and the source, and "
              "change provenance from ASSUMPTION.".format(DEFAULT_FILE))
        print("Then pass --defaults with your copy to any other command.")
    return 0


def budget(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yerkon budget",
        description=(
            "Take each scenario's position error apart, one source at a "
            "time, and say which source is worth removing. Every line is "
            "the same simulation the table uses, re-run with one error "
            "silenced, spread over as many cores as the machine spares."
        ),
    )
    parser.add_argument(
        "--only", action="append", choices=sorted(SCENARIO_CHOICES),
        help="dissect only these scenarios; repeat the flag for several",
    )
    parser.add_argument(
        "--source", action="append", choices=list(SOURCE_NAMES),
        help=(
            "dissect only these error sources; repeat the flag for "
            "several. The default is all of them."
        ),
    )
    _add_defaults_flag(parser)
    _add_option_flag(parser)
    args = parser.parse_args(argv)

    try:
        settings = _settings_from(args)
    except (FileNotFoundError, ValueError) as error:
        print(error, file=sys.stderr)
        return 2

    from yerkon.budget import dissect_all
    from yerkon.scenarios import catalogue

    available = catalogue(settings) if settings else SCENARIO_CHOICES
    chosen = (
        tuple(available[name] for name in args.only)
        if args.only else tuple(available.values())
    )
    sources = tuple(args.source) if args.source else SOURCE_NAMES

    runs = len(chosen) * (2 * len(sources) + 2)
    print(
        "Running {} simulations: {} scenario{} against {} error "
        "source{}. This takes a few minutes.".format(
            runs, len(chosen), "" if len(chosen) == 1 else "s",
            len(sources), "" if len(sources) == 1 else "s",
        ),
        file=sys.stderr,
    )
    print("Spread over {} processes.".format(workers()), file=sys.stderr)

    print(as_breakdown(dissect_all(chosen, sources)))
    return 0


def options(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yerkon options",
        description=(
            "List the named deployment options on hand and say what each "
            "one changes. An option is a short list of edits to the "
            "settings file, so it composes with --defaults rather than "
            "replacing it. `yerkon solve --save` writes new ones."
        ),
    )
    parser.add_argument("name", nargs="?",
                        help="show one option in full rather than listing all")
    args = parser.parse_args(argv)

    from yerkon.options import available, read
    from yerkon.settings import DEFAULTS

    names = available()
    if not names:
        print("No options on hand. `yerkon solve --save NAME` writes one.")
        return 0

    if args.name:
        try:
            option = read(args.name)
        except (FileNotFoundError, ValueError) as error:
            print(error, file=sys.stderr)
            return 2
        print(option.describe(DEFAULTS))
        print()
        print(option.note)
        print()
        print("Run it with: yerkon table --option {}".format(option.name))
        return 0

    for name in names:
        option = read(name)
        print(option.describe(DEFAULTS))
        print("    {}".format(option.note.split("\n")[0]))
        print()
    print("Any of them: yerkon table --option NAME")
    return 0


def solve(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yerkon solve",
        description=(
            "Search deployment arrangements for the cheapest that meets a "
            "target, and optionally save it as a named option. Every "
            "candidate is a full simulation against real ground, spread "
            "over as many cores as the machine spares. Its answers agree "
            "with the table by construction."
        ),
    )
    parser.add_argument("--scenario", default="rural",
                        choices=sorted(SCENARIO_CHOICES),
                        help="which row to search")
    parser.add_argument("--availability", type=float, default=0.0,
                        help="share of attempted fixes that must produce a "
                             "position, for example 0.95")
    parser.add_argument("--hpe-p50", type=float, default=None, metavar="M",
                        help="horizontal error at the fiftieth percentile, "
                             "in metres, at most")
    parser.add_argument("--hpe-p95", type=float, default=None, metavar="M",
                        help="horizontal error at the ninety-fifth "
                             "percentile, in metres, at most")
    parser.add_argument("--fixes", type=float, default=0.0, metavar="PER_S",
                        help="fixes a unit must get per second, at least")
    parser.add_argument("--vary", action="append", metavar="KEY=A,B,C",
                        help="a settings figure to search and the values to "
                             "try. Repeat for several. Defaults to a short "
                             "list per scenario.")
    parser.add_argument("--save", metavar="NAME",
                        help="save the winner as an option under this name")
    _add_defaults_flag(parser)
    _add_option_flag(parser)
    args = parser.parse_args(argv)

    import math

    from yerkon.numbers import decimal_comma
    from yerkon.options import write
    from yerkon.settings import DEFAULTS
    from yerkon.solve import SEARCHABLE, AlreadyMet, Target, search

    try:
        settings = _settings_from(args) or DEFAULTS
        over = _varying(args.vary)
    except (FileNotFoundError, ValueError) as error:
        print(error, file=sys.stderr)
        return 2

    target = Target(
        availability=args.availability,
        hpe_p50_m=math.inf if args.hpe_p50 is None else args.hpe_p50,
        hpe_p95_m=math.inf if args.hpe_p95 is None else args.hpe_p95,
        fixes_per_second=args.fixes,
    )
    knobs = over or SEARCHABLE.get(args.scenario) or {}
    candidates = 1
    for values in knobs.values():
        candidates *= len(values)

    print("Searching {} arrangements of the {} row for: {}".format(
        candidates, args.scenario, target.describe()), file=sys.stderr)
    print("Each is a full simulation, spread over {} processes.".format(
        workers()), file=sys.stderr)

    seen = [0]

    def note(outcome):
        seen[0] += 1
        print("  [{:3d}/{:3d}] {:4d} anchors  avail {:6.2%}  HPE50 {:5.2f}  "
              "{:>12} TL  {}".format(
                  seen[0], candidates, outcome.anchors, outcome.availability,
                  outcome.hpe_p50_m, decimal_comma(outcome.capex_tl, 0),
                  "meets" if target.met_by(outcome) else "",
              ), file=sys.stderr)

    try:
        found = search(args.scenario, target, over, settings, watching=note)
    except ValueError as error:
        print(error, file=sys.stderr)
        return 2

    best = found.best
    if best is None:
        print("\nNothing met {}.".format(target.describe()))
        print("{} arrangements tried. The closest reached {:.2%} "
              "availability at {} TL.".format(
                  len(found.tried),
                  max(o.availability for o in found.tried),
                  decimal_comma(min(o.capex_tl for o in found.tried), 0)))
        print("Widen the search with --vary, or ask for less.")
        return 1

    print("\n{} of {} arrangements met it. The cheapest:".format(
        len(found.met), len(found.tried)))
    for key, value in sorted(best.values.items()):
        was = settings.number(key)
        print("  {:<40} {} -> {}".format(key, readable(was), readable(value)))
    print("\n  {} anchors, {} TL to build, {} TL a year to run".format(
        best.anchors, decimal_comma(best.capex_tl, 0),
        decimal_comma(best.opex_tl_per_year, 0)))
    print("  availability {:.2%}, HPE P50 {} m, P95 {} m, {} fixes a second".format(
        best.availability, decimal_comma(best.hpe_p50_m, 2),
        decimal_comma(best.hpe_p95_m, 2),
        decimal_comma(best.fixes_per_second, 2)))

    if args.save:
        try:
            path = write(found.as_option(args.save, settings))
        except AlreadyMet as nothing_to_do:
            print("\n{}.".format(nothing_to_do))
            return 0
        print("\nSaved as {}. Run it with: yerkon table --option {}".format(
            path, args.save))
    else:
        print("\nPass --save NAME to keep this as an option.")
    return 0


def _varying(pairs: list[str] | None) -> dict | None:
    """Parse --vary KEY=A,B,C, saying what went wrong rather than raising."""
    if not pairs:
        return None
    over = {}
    for pair in pairs:
        key, _, listed = pair.partition("=")
        if not listed:
            raise ValueError(
                "--vary wants KEY=A,B,C; {!r} has no values".format(pair)
            )
        try:
            over[key] = tuple(float(v) for v in listed.split(","))
        except ValueError:
            raise ValueError(
                "--vary {} has something that is not a number".format(key)
            ) from None
    return over


def deliver(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yerkon deliver",
        description=(
            "Write the study out as Markdown: the four rows, the error "
            "budget behind them, every figure and what it rests on, and "
            "the deployments that could be built instead. Everything "
            "this project knows, as files somebody can hand over."
        ),
    )
    parser.add_argument(
        "--into", default="docs/teslim", metavar="DIR",
        help="where to write the files (default: docs/teslim)",
    )
    parser.add_argument(
        "--only", action="append", choices=sorted(SCENARIO_CHOICES),
        help="write only these scenarios; repeat the flag for several",
    )
    parser.add_argument(
        "--no-budget", action="store_true",
        help=(
            "skip the error budget, which is by far the slowest part. "
            "Use it when only the table needs refreshing."
        ),
    )
    _add_defaults_flag(parser)
    _add_option_flag(parser)
    args = parser.parse_args(argv)

    try:
        settings = _settings_from(args)
    except (FileNotFoundError, ValueError) as error:
        print(error, file=sys.stderr)
        return 2

    from yerkon.deliver import deliver as write_it
    from yerkon.scenarios import catalogue
    from yerkon.settings import DEFAULTS

    settings = settings or DEFAULTS
    available = catalogue(settings)
    chosen = (
        tuple(available[name] for name in args.only)
        if args.only else tuple(available.values())
    )

    print("Writing {} scenario{} into {} on {} processes.".format(
        len(chosen), "" if len(chosen) == 1 else "s", args.into, workers(),
    ), file=sys.stderr)

    written = write_it(
        args.into, chosen, settings,
        with_budget=not args.no_budget,
        tell=lambda line: print("  " + line, file=sys.stderr),
    )
    print()
    for one in written:
        print("{}  —  {}".format(one.path, one.about))
    return 0


def place(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yerkon place",
        description=(
            "Put a row's anchors on places that are already high instead "
            "of on its grid: existing columns and signs, roofs with a "
            "measured height, hilltops and the road side. Chosen by a "
            "cost-weighted cover search over the real link budget, then "
            "simulated beside the grid (ADR-0081)."
        ),
    )
    parser.add_argument("--scenario", default="urban",
                        choices=("urban", "rural"), help="which row")
    parser.add_argument("--aim", default="better",
                        choices=("better", "cheaper"),
                        help="better: most cover for the grid's cost; "
                             "cheaper: the grid's cover for least cost")
    parser.add_argument("--no-simulation", action="store_true",
                        help="stop at the search's own count")
    _add_defaults_flag(parser)
    args = parser.parse_args(argv)

    from yerkon.cost import operating_rates
    from yerkon.placement import deployed_with, mix, search
    from yerkon.scenarios import catalogue, fetched
    from yerkon.settings import DEFAULTS, is_hurried

    settings = _settings_from(args) or DEFAULTS
    row = args.scenario
    deployed = catalogue(settings)[row]
    site = fetched(settings.text(row + ".site"))
    if site is None:
        print("The {} row stands on no fetched ground, and the search reads "
              "its structures, buildings and roads from it.".format(row),
              file=sys.stderr)
        return 2

    print("Trying every candidate with the link budget on {} "
          "processes.".format(workers()), file=sys.stderr)
    answer = search(deployed, site, row, args.aim, settings)
    p = answer.problem
    print("candidates: {}".format(", ".join(
        "{} {}".format(n, origin)
        for origin, n in mix(p, range(len(p.candidates))).items())))
    print("{:<10}{:>8}{:>12}{:>18}".format("", "anchors", "served", "lifecycle TL"))
    for name, share, cost, count in (
        ("grid", answer.grid_share, answer.grid_lifecycle_tl, len(p.grid)),
        ("search", answer.share, answer.lifecycle_tl, len(answer.chosen)),
    ):
        print("{:<10}{:>8}{:>12}{:>18}".format(
            name, count, "%" + decimal_comma(100.0 * share, 1),
            decimal_comma(cost, 0)))
    print("chosen: {}".format(", ".join(
        "{} {}".format(n, origin)
        for origin, n in mix(p, answer.chosen).items())))
    if args.no_simulation:
        return 0

    from yerkon.report import build

    _, rows = build(
        deployments=(deployed, deployed_with(deployed, p, answer.chosen)),
        rates=operating_rates(settings))
    print()
    print("{:<10}{:>8}{:>8}{:>10}{:>10}{:>12}{:>10}".format(
        "", "P50", "P95", "avail", "km²", "capex/km²", "opex/km²"))
    for name, one in zip(("grid", "search"), rows):
        cells = one.cells()
        print("{:<10}{:>8}{:>8}{:>10}{:>10}{:>12}{:>10}".format(
            name, cells[3], cells[4], cells[6], cells[7], cells[8], cells[9]))
    if is_hurried(settings):
        print("\nRead coarsely (--fast): for trying, not for publishing.")
    return 0


def calibrate(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yerkon calibrate",
        description=(
            "Read a measurement from the MATLAB scripts and print the "
            "defaults.toml entry that replaces the figure it stands in "
            "for. Nothing is written; the entry is printed to be pasted."
        ),
    )
    parser.add_argument("files", nargs="+", metavar="CSV",
                        help="what a MATLAB script wrote")
    args = parser.parse_args(argv)

    from yerkon.calibrate import read
    from yerkon.settings import DEFAULTS

    measured = []
    for path in args.files:
        try:
            measured.append(read(path))
        except (FileNotFoundError, ValueError) as error:
            print(error, file=sys.stderr)
            return 2

    for one in measured:
        try:
            was = DEFAULTS.number(one.key)
        except KeyError:
            was = None
        print("# {}".format(one.key))
        if was is not None:
            print("#   default {} {} -> measured {} {}".format(
                readable(was), one.unit, readable(one.value), one.unit))
            if was != 0.0:
                print("#   a factor of {} {}".format(
                    readable(max(was, one.value) / min(was, one.value)),
                    "better" if one.value < was else "worse",
                ))
        print(one.as_toml())
        print()

    print("# Paste these over the matching entries in defaults.toml,")
    print("# then re-run anything with --defaults pointing at it.")
    return 0


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in {"-h", "--help"}:
        print(__doc__.strip())
        print("\nUsage:")
        print("  yerkon fetch  --south .. --west .. --north .. --east .. --into DIR")
        print("  yerkon design [--region TR] [--mounting mast] [--tolerance 5]")
        print("  yerkon table  [--markdown] [--only rural] [--publish]")
        print("  yerkon view   [--port 8765]        # the site and the simulator")
        print("  yerkon pages  [--into docs]        # the site as files")
        print("  yerkon site   [--corridor 12000] [--tolerance 5] [--ground polatli]")
        print("  yerkon budget [--only tunnel] [--source survey]")
        print("  yerkon deliver [--into docs/teslim] [--no-budget]")
        print("  yerkon options [NAME]")
        print("  yerkon solve  --scenario rural --availability 0.95 --save NAME")
        print("  yerkon place  --scenario urban [--aim better|cheaper] [--fast]")
        print("  yerkon defaults [--full]")
        print("  yerkon calibrate out/clock_residual.csv")
        return 0
    verb, rest = argv[0], argv[1:]
    if verb == "fetch":
        return fetch(rest)
    if verb == "design":
        return design(rest)
    if verb == "table":
        return table(rest)
    if verb == "view":
        return view(rest)
    if verb == "site":
        return site(rest)
    if verb == "pages":
        return pages(rest)
    if verb == "budget":
        return budget(rest)
    if verb == "deliver":
        return deliver(rest)
    if verb == "options":
        return options(rest)
    if verb == "solve":
        return solve(rest)
    if verb == "place":
        return place(rest)
    if verb == "defaults":
        return defaults(rest)
    if verb == "calibrate":
        return calibrate(rest)
    print("Unknown command: {}".format(verb), file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
