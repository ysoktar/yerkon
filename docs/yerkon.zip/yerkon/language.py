"""Which language the study speaks, and the sentences it builds itself.

Two, and they are not a translation of one another in the sense that one
is the original: the figures, the notes and the reasons are written in
both and the file carries both. Turkish because the report this answers
is Turkish and the people who will check it work in Turkish; English
because the code, the decisions and the tests are in English and a reader
of those should not have to leave them to read what a figure means.

Nothing here decides anything. A language chooses which of two strings is
shown, and no number, no geometry and no result differs between them. A
test pins that: the whole table is built twice and the figures match.

Two kinds of text live in two different places, on purpose.

Text somebody *wrote* — what a figure rests on, what an option buys —
lives beside the value it describes, in ``defaults.toml`` and in the
option files, as ``note`` and ``note_en``. Keeping both beside one value
is what stops the two languages drifting into two different claims about
the same number.

Text this project *builds* — "rolling, 400 m over 1200 m" — lives here,
as a pair of format strings under one name. There are few of them and
they are the ones that would otherwise be hardcoded mid-computation.
"""

from __future__ import annotations

#: The languages, in the order a chooser should offer them.
LANGUAGES = ("tr", "en")

#: What each is called, in itself.
LANGUAGE_NAMES = {"tr": "Türkçe", "en": "English"}

#: The one a caller gets when it does not say.
#:
#: Turkish, because the report is Turkish and the viewer is the main way
#: into this project (ADR-0035).
DEFAULT_LANGUAGE = "tr"


#: Numbers are written the same way in both.
#:
#: A comma decimal mark and no thousands separator, which is what the
#: report uses. The English here is a way into the same study rather than
#: a second study, and a figure with two written forms is a figure
#: somebody can quote two ways.
NUMBERS_ARE_TURKISH = True


def chosen(language: str | None) -> str:
    """A language name, checked, or the default when none was given."""
    if language is None:
        return DEFAULT_LANGUAGE
    if language not in LANGUAGES:
        raise ValueError(
            "no language called {!r}. There are: {}".format(
                language, ", ".join(LANGUAGES)
            )
        )
    return language


#: Every sentence this project builds rather than reads from a file.
#:
#: One name, two format strings, the same fields in both. A sentence
#: missing from either language fails a test rather than falling back,
#: because a fallback is a half-translated page nobody notices.
CATALOGUE: dict[str, dict[str, str]] = {
    # -- the three rows of the table ---------------------------------------
    "row.urban": {"tr": "Şehir içi", "en": "Urban"},
    "row.rural": {"tr": "Kırsal", "en": "Rural"},
    "row.tunnel": {"tr": "Tünel", "en": "Tunnel"},
    # -- what the ground is -----------------------------------------------
    "terrain.flat": {
        "tr": "{elevation_m:.0f} m'de düz",
        "en": "flat at {elevation_m:.0f} m",
    },
    "terrain.flat.plain": {"tr": "düz", "en": "flat"},
    "terrain.rolling": {
        "tr": "tepeli, {wavelength_m:.0f} m'de {amplitude_m:.0f} m",
        "en": "rolling, {amplitude_m:.0f} m over {wavelength_m:.0f} m",
    },
    "terrain.bore": {
        "tr": "tünel, {length_m:.0f} m'de %{grade}",
        "en": "bore, {grade}% over {length_m:.0f} m",
    },
    "terrain.bore.through": {
        "tr": "{site} içinden tünel, portalları {source} kaynağından",
        "en": "bore through {site}, portals from {source}",
    },
    # -- what a fetched site is -------------------------------------------
    "site.ground": {
        "tr": "{source} kaynağından zemin, {resolution_m:.0f} m çözünürlükte",
        "en": "ground from {source} at {resolution_m:.0f} m",
    },
    "site.buildings": {
        "tr": "{source} kaynağından {count} bina",
        "en": "{count} buildings from {source}",
    },
    "site.no_buildings": {
        "tr": "bina verisi bulunmadığından her yerde açık arazi "
              "varsayılmıştır",
        "en": "no building data, so open ground is assumed everywhere",
    },
    "site.heights_tagged": {
        "tr": "{tagged} bina yüksekliği etiketten alınmış, {levels} "
              "tanesi kat sayısından hesaplanmış, {defaulted} tanesi için"
              " {default_m:.0f} m varsayılmıştır",
        "en": "{tagged} building heights tagged, {levels} from storey "
              "counts, {defaulted} defaulted to {default_m:.0f} m",
    },
    "site.footprints": {
        "tr": "OpenStreetMap'ten bina dış hatları değil merkez noktaları "
              "indirildiğinden taban alanları, yükseklikten türetilen "
              "alana sahip daireler olarak modellenmiştir. Bağlantı "
              "bütçesi için yalnızca bir binanın sinyal yolu üzerinde "
              "bulunup bulunmadığı önemlidir.",
        "en": "Footprints are circles of an area implied by height, "
              "because OpenStreetMap centres were fetched rather than "
              "outlines. A link budget only asks whether a building is in "
              "the way.",
    },
    "site.unreachable": {
        "tr": "{name} kaynağına erişilemedi: {error}",
        "en": "{name} unavailable: {error}",
    },
    "site.no_answer": {
        "tr": "{name} yanıt vermedi: {error}",
        "en": "{name} did not answer: {error}",
    },
    "site.footprints_measured": {
        "tr": "Taban alanları, her binanın kendi sınır kutusundan "
              "ölçülmüştür ({release} sürümü); yükseklikten "
              "türetilmemiştir.",
        "en": "Footprints are measured from each building's own bounding "
              "box (release {release}), not implied by height.",
    },
    "point.none": {
        "tr": "Merkez girilmedi. Haritada ilgili yere sağ tıklayıp "
              "koordinatı yapıştırınız; örneğin 39,9250 32,8370",
        "en": "No centre given. Right-click the place on a map and paste "
              "what it gives you, for example 39.9250, 32.8370",
    },
    "point.unreadable": {
        "tr": "{text!r} enlem ve boylam olarak okunamadı. Lütfen 39,9250 "
              "32,8370 veya 39.9250, 32.8370 biçiminde giriniz.",
        "en": "{text!r} does not read as a latitude and a longitude. Write "
              "them as 39,9250 32,8370 or 39.9250, 32.8370",
    },
    "point.not_a_latitude": {
        "tr": "{value} geçerli bir enlem değildir; enlem -90 ile 90 "
              "arasında olmalıdır. Önce enlem girilmelidir.",
        "en": "{value} is not a latitude; it runs from -90 to 90. Latitude "
              "comes first.",
    },
    "point.not_a_longitude": {
        "tr": "{value} geçerli bir boylam değildir; boylam -180 ile 180 "
              "arasında olmalıdır.",
        "en": "{value} is not a longitude; it runs from -180 to 180.",
    },
    # -- routes a receiver drives (ADR-0045) -------------------------------
    "route.site": { "tr": "Sahanın kendi şekli", "en": "The site's own shape" },
    "route.line": { "tr": "Düz çizgi", "en": "A straight line" },
    "route.out-and-back": { "tr": "Gidiş-dönüş", "en": "Out and back" },
    "route.circuit": { "tr": "Çevre turu", "en": "A circuit" },
    "route.figure-eight": { "tr": "Sekiz çizerek", "en": "A figure of eight" },
    "route.lawnmower": { "tr": "Şerit şerit tarama", "en": "Lawnmower passes" },
    "route.waypoints": { "tr": "Rastgele duraklar", "en": "Random waypoints" },
    "route.road": { "tr": "Gerçek yol", "en": "The real road" },
    "route.no_road": {
        "tr": "Bu zeminde yol geometrisi bulunmadığından gerçek yol "
              "güzergâhı çizilememektedir. Saha indirilirken yol "
              "verisinin de indirilmesi gerekmektedir.",
        "en": "This ground carries no road geometry, so the real road "
              "cannot be drawn. A fetch has to bring roads too.",
    },
    "deployment.no_anchors": {
        "tr": "Yayın birimi bulunmamaktadır: hiçbir grup birim "
              "yerleştirmemekte veya tüm birimler silinmiş durumdadır. "
              "Elle yerleşim bilinçli olarak boş başlamaktadır: birimleri"
              " sürükleyerek yerleştiriniz veya başka bir yöntem seçiniz."
              " (Boş bir düzenleme çizilebilir, ancak çalıştırılamaz.)",
        "en": "No broadcast units: every group either places none or has had "
              "them all removed. The by-hand layout starts empty on purpose: "
              "drag units in, or choose another method. (An empty arrangement "
              "can be drawn; it cannot be run.)",
    },
    # -- named arrangements (ADR-0043) ------------------------------------
    "preset.bad_name": {
        "tr": "{name!r} geçerli bir düzenleme adı değildir: ad harf veya "
              "rakamla başlamalı ve yalnızca harf, rakam, tire ve alt "
              "çizgi içermelidir.",
        "en": "{name!r} is not an arrangement name: it starts with a letter "
              "or a digit and holds letters, digits, dashes and underscores.",
    },
    "preset.unknown": {
        "tr": "{directory} içinde {name!r} adlı bir düzenleme "
              "bulunmamaktadır. Mevcut düzenlemeler: {known}",
        "en": "No arrangement called {name!r} in {directory}. "
              "There are: {known}",
    },
    "preset.unreadable": {
        "tr": "{path} okunamadı: {error}",
        "en": "{path} could not be read: {error}",
    },
    "preset.incomplete": {
        "tr": "{source} geçerli bir düzenleme değildir; eksik alan: "
              "{missing}",
        "en": "{source} is not an arrangement; it is missing: {missing}",
    },
    "preset.from": {
        "tr": "{mode} satırı {name!r} düzenlemesiyle çalıştırıldı "
              "({source}, içerik {digest})",
        "en": "the {mode} row ran from the arrangement {name!r} "
              "({source}, contents {digest})",
    },
    "preset.default": {"tr": "Varsayılan", "en": "Default"},
    "preset.empty": {"tr": "Boş", "en": "Empty"},
    "site.roads": {
        "tr": "{name} kaynağından {count} yol parçası ({classes})",
        "en": "{count} road segments from {name} ({classes})",
    },
    "site.no_roads": {
        "tr": "{name} bu kutuda izlenecek bir yol bulamadı",
        "en": "{name} found no road to drive in this box",
    },
    "site.furniture": {
        "tr": "{name} kaynağından birim takılabilecek {count} yapı ({kinds})",
        "en": "{count} mountable structures from {name} ({kinds})",
    },
    "site.no_furniture": {
        "tr": "{name} bu kutuda birim takılabilecek yapı bulamadı",
        "en": "{name} found no mountable structure in this box",
    },
    "site.needs_pillow": {
        "tr": "Hava görüntüsü Pillow paketini gerektirir: "
              "pip install \"yerkon[sites]\"",
        "en": "Aerial imagery needs Pillow: pip install \"yerkon[sites]\"",
    },
    "site.no_imagery_url": {
        "tr": "Hava görüntüsü için bir karo adresi verilmemiştir. "
              "Sağlayıcı kullanıcı tarafından seçilmelidir: her "
              "sağlayıcının kendi kullanım koşulları bulunmakta ve çoğu "
              "bir erişim anahtarı gerektirmektedir. Örnek bir "
              'yapılandırma README.md dosyasının "Yeni bir saha getirmek"'
              " başlığında yer almaktadır.",
        "en": "No tile URL given for the imagery. You choose the provider: "
              "each has its own terms and most want a key. There is an "
              "example in README.md, under \"Yeni bir saha getirmek\".",
    },
    "site.too_many_tiles": {
        "tr": "{zoom} yakınlıkta {tiles} karo gerekmektedir; sınır "
              "{most}. Daha düşük bir yakınlık veya daha küçük bir kutu "
              "seçiniz.",
        "en": "{tiles} tiles at zoom {zoom}, and the limit is {most}. Pick a "
              "lower zoom or a smaller box.",
    },
    "site.no_tiles": {
        # No name in it: the note that carries this to a person already
        # names the source, and "aerial imagery unreachable: aerial
        # imagery returned no tiles" is a sentence nobody wrote on
        # purpose.
        "tr": "hiçbir karo alınamadı. Adres şablonunu, erişim anahtarını "
              "ve ağ bağlantısını kontrol ediniz.",
        "en": "no tiles came back at all. Check the URL template, the key "
              "and the network.",
    },
    "site.aerial": {
        # Pre-formatted by the caller rather than `:.2f` here, because
        # this project writes a comma decimal mark and a format spec
        # would write a dot. The neighbouring elevation phrase gets away
        # with `:.0f` only because no separator ever shows.
        "tr": "{source} kaynağından hava görüntüsü, {resolution_m} m/piksel",
        "en": "aerial imagery from {source} at {resolution_m} m/pixel",
    },
    "site.needs_pyarrow": {
        "tr": "Overture erişimi pyarrow paketini gerektirir: "
              "pip install -e \".[dev,sites]\"",
        "en": "Overture access needs pyarrow: "
              "pip install -e \".[dev,sites]\"",
    },
    "site.needs_rasterio": {
        "tr": "GeoTIFF okumak rasterio paketini gerektirir: "
              "pip install -e \".[dev,sites]\"",
        "en": "Reading a GeoTIFF needs rasterio: "
              "pip install -e \".[dev,sites]\"",
    },
    "site.needs_requests": {
        "tr": "Ağdan veri çekmek requests paketini gerektirir: "
              "pip install -e \".[dev,sites]\"",
        "en": "Fetching over the network needs requests: "
              "pip install -e \".[dev,sites]\"",
    },
    "site.no_elevation": {
        "tr": "Hiçbir yükseklik kaynağı yanıt vermedi.\n  {detail}",
        "en": "No elevation source answered.\n  {detail}",
    },
    "site.no_sources": {
        "tr": "hiçbir kaynak verilmedi",
        "en": "no sources were given",
    },
    # -- what the solver was asked for, and what it found ------------------
    "target.availability": {
        "tr": "kullanılabilirlik ≥ %{availability}",
        "en": "availability ≥ {availability} %",
    },
    "target.hpe_p50": {"tr": "HPE P50 ≤ {value} m", "en": "HPE P50 ≤ {value} m"},
    "target.hpe_p95": {"tr": "HPE P95 ≤ {value} m", "en": "HPE P95 ≤ {value} m"},
    "target.fixes": {
        "tr": "saniyede {value} konum",
        "en": "{value} fixes a second",
    },
    "target.nothing": {
        "tr": "belirli bir hedef tanımlanmamıştır",
        "en": "nothing in particular",
    },
    "solve.none_met": {
        "tr": "{target} koşulunu karşılayan bir yerleşim bulunamadı; "
              "kaydedilecek bir seçenek bulunmamaktadır",
        "en": "nothing met {target}; there is no option to save",
    },
    "solve.already_met": {
        "tr": "mevcut ayarlar {target} koşulunu zaten karşılamaktadır; bu"
              " koşulu karşılayan en düşük maliyetli yerleşim mevcut "
              "yerleşimdir, dolayısıyla kaydedilecek yeni bir seçenek "
              "bulunmamaktadır",
        "en": "the settings already meet {target}; the cheapest arrangement "
              "that meets it is the one you have, so there is nothing to "
              "save",
    },
    "solve.title": {
        "tr": "{scenario}: {target}, {anchors} yayın birimi, {capex} TL",
        "en": "{scenario}: {target}, {anchors} broadcast units, {capex} TL",
    },
    "solve.note": {
        "tr": "{scenario} senaryosu için {tried} yerleşim, senaryonun "
              "gerçek zemini üzerinde denenmiş; {target} koşulunu "
              "karşılayanlar arasından en düşük maliyetli olanı "
              "seçilmiştir.\n\nSeçilen yerleşim {anchors} yayın birimiyle "
              "%{availability} kullanılabilirlik, ellinci yüzdelikte "
              "{hpe_p50} m, doksan beşinci yüzdelikte {hpe_p95} m hata ve"
              " saniyede {fixes} konum sağlamaktadır.\n\nHer aday, yaklaşık"
              " bir model yerine tam bir simülasyonla "
              "değerlendirilmiştir; dolayısıyla bu değerler tablonun "
              "hesaplandığı motorla aynı yöntemden elde edilmektedir.",
        "en": "Found by searching {tried} arrangements of the {scenario} "
              "row against the real ground it stands on, and keeping the "
              "cheapest that met {target}.\n\n"
              "It delivers {availability} % availability, {hpe_p50} m at "
              "the fiftieth percentile and {hpe_p95} m at the ninety-fifth, "
              "at {fixes} fixes a second, from {anchors} broadcast units.\n\n"
              "Every candidate was a full simulation rather than a fitted "
              "model, so these figures come from the same engine the table "
              "does.",
    },
    # -- the named ways of laying anchors out ------------------------------
    #
    # Each one says what it does rather than what it is called, because
    # "hex" means nothing to somebody who has not read the module and
    # "the fewest anchors that cover an area" means everything.
    "layout.grid": {
        "tr": "Düzenli ızgara",
        "en": "Regular grid",
    },
    "layout.hex": {
        "tr": "Petek ızgara: alanı en az birimle kapsar",
        "en": "Honeycomb grid: covers the area with the fewest units",
    },
    "layout.corridor": {
        "tr": "Yol boyunca, iki yanda sırayla",
        "en": "Along the road, taking each side in turn",
    },
    "layout.perimeter": {
        "tr": "Yalnız sahanın kenarında",
        "en": "Only round the edge of the site",
    },
    "layout.greedy-coverage": {
        "tr": "Otomatik: sinyalin en geniş alana ulaşması",
        "en": "Automatic: the signal reaches the widest area",
    },
    "layout.greedy-dop": {
        "tr": "Otomatik: en iyi konum geometrisi",
        "en": "Automatic: the best geometry for a position",
    },
    "layout.k-cover": {
        "tr": "Otomatik: her noktaya dört birimin ulaşması",
        "en": "Automatic: four units over every point",
    },
    "layout.placed": {
        "tr": "En iyi yerleşim: var olan direkler ve yapılar (tablonun kullandığı)",
        "en": "Best layout: existing poles and structures (what the table uses)",
    },
    "layout.manual": {
        "tr": "Elle: boş başlangıç, birimler kullanıcı tarafından "
              "yerleştirilir",
        "en": "By hand: start empty and put the units yourself",
    },
    # The four kinds the list is grouped under, so the nine read as four
    # decisions rather than nine names.
    "layout.group.pattern": {"tr": "Hazır desenler", "en": "Ready patterns"},
    "layout.group.search": {"tr": "Otomatik arama", "en": "Automatic search"},
    "layout.group.standing": {"tr": "Var olan yapılar",
                              "en": "Structures already standing"},
    "layout.group.hand": {"tr": "Elle", "en": "By hand"},
    "layout.needs_map": {
        "tr": "Bu yöntem yol kenarındaki yapıları kullanmaktadır; ancak "
              "bu zeminde indirilmiş yol verisi bulunmamaktadır.",
        "en": "This method uses the structures beside the road, and this "
              "ground carries no fetched road data.",
    },
    # -- why the confirmation panel says a figure has to move ------------
    "panel.past_the_site": {
        "tr": "sahanın sınırını aşan bir yayın birimi, modelde bulunmayan"
              " bir zeminde yer alır ve hiçbir alıcı oradan geçmez",
        "en": "a broadcast unit past the end of the site stands on ground the "
              "simulation does not model, and no receiver passes it",
    },
    "panel.filled_the_ground": {
        "tr": "saha, indirilen zeminin tamamını kapsamaktadır ve bu "
              "şekilde korunmaktadır",
        "en": "the site was the whole of its ground and stays so",
    },
    "panel.past_the_measurement": {
        "tr": "bir saha, kendisi için indirilen zeminden büyük olamaz; "
              "sınırın ötesinde yalnızca kenar verisinin düz bir yüzeye "
              "uzatılmış hâli bulunmaktadır",
        "en": "a site is no larger than the ground fetched for it; past the "
              "edge there is only the boundary row extruded into a plane",
    },
    "panel.site_length": {"tr": "Sahanın boyu", "en": "The site's length"},
    "panel.site_width": {"tr": "Sahanın eni", "en": "The site's width"},
    "panel.ground": {"tr": "Zemin", "en": "Ground"},
    # -- what a long task says while it runs -------------------------------
    #
    # These are the lines the page shows while a job is going. They are
    # here rather than beside the code that prints them for the same
    # reason everything else is: a task started from the page in English
    # that reports in Turkish is the half-and-half surface ADR-0035 was
    # written to end.
    "task.table.running": {
        "tr": "{rows} senaryo {workers} süreçte çalıştırılıyor.",
        "en": "Running {rows} row{s} on {workers} processes.",
    },
    "task.budget.running": {
        "tr": "{runs} simülasyon çalıştırılıyor: {rows} senaryo, "
              "{sources} hata kaynağı, {workers} süreç.",
        "en": "Running {runs} simulations: {rows} scenario{s} against "
              "{sources} sources, on {workers} processes.",
    },
    "task.done": {"tr": "Tamamlandı.", "en": "Done."},
    "task.solve.searching": {
        "tr": "{scenario} için {candidates} yerleşim, {target} hedefine karşı, "
              "{workers} süreçte aranıyor.",
        "en": "Searching {candidates} arrangements of {scenario} for "
              "{target}, on {workers} processes.",
    },
    "task.solve.candidate": {
        "tr": "[{seen}/{candidates}] {anchors} yayın birimi · {availability} "
              "kullanılabilirlik · HPE50 {hpe_p50} m · {capex} TL{meets}",
        "en": "[{seen}/{candidates}] {anchors} broadcast units · {availability} "
              "availability · HPE50 {hpe_p50} m · {capex} TL{meets}",
    },
    "task.solve.meets": {"tr": "  ← karşılıyor", "en": "  ← meets"},
    "task.solve.none_met": {
        "tr": "Hiçbir yerleşim koşulu karşılamadı.",
        "en": "Nothing met it.",
    },
    "task.solve.met": {
        "tr": "{tried} yerleşimin {met} tanesi koşulu karşıladı.",
        "en": "{met} of {tried} met it.",
    },
    "task.solve.saved": {
        "tr": "{name} adıyla kaydedildi.",
        "en": "Saved as {name}.",
    },
    "task.place.searching": {
        "tr": "{scenario}: {candidates} aday yer ({kinds}), {cells} hücre, "
              "{workers} süreçte bağlantı bütçesiyle deneniyor.",
        "en": "{scenario}: trying {candidates} candidate places ({kinds}) "
              "against {cells} cells with the link budget, on {workers} "
              "processes.",
    },
    "task.place.progress": {
        "tr": "Denenen aday: %{share}",
        "en": "Candidates tried: {share} %",
    },
    "task.place.chose": {
        "tr": "{anchors} yayın birimi konumu seçildi ({kinds}). Hizmet "
              "verilen hücre oranı %{share} (mevcut yerleşim "
              "%{grid_share}); ömür boyu maliyet {cost} TL (mevcut "
              "yerleşim {grid_cost} TL).",
        "en": "Chose {anchors} broadcast unit sites ({kinds}). Cells served {share} % "
              "(current layout {grid_share} %); lifecycle cost {cost} TL "
              "(current layout {grid_cost} TL).",
    },
    "task.place.needs_ground": {
        "tr": "En iyi yerleşim araması ölçülmüş bir zemin "
              "gerektirmektedir: yapılar, binalar ve yollar bu zeminden "
              "okunmaktadır.",
        "en": "The placement search needs measured ground: it reads the "
              "structures, buildings and roads from it.",
    },
    # The anchors the row already had, whatever laid them out: the
    # search keeps them as candidates so it can never do worse.
    "place.origin.grid": {"tr": "mevcut yerleşimden", "en": "from the current layout"},
    "place.origin.furniture": {"tr": "var olan direkler ve tabelalar",
                               "en": "existing columns and signs"},
    "place.origin.rooftop": {"tr": "çatı", "en": "rooftop"},
    "place.origin.hilltop": {"tr": "tepe", "en": "hilltop"},
    "place.origin.road": {"tr": "yol kenarı", "en": "road side"},
    # A middle dot rather than a comma between the two halves of a
    # coordinate: the decimal mark here is a comma too (ADR-0035), and
    # "39,9208,32,8541" is four numbers to anybody reading it.
    "task.fetch.fetching": {
        "tr": "{south} · {west} ile {north} · {east} arası {spacing_m} m "
              "aralıkla indiriliyor.",
        "en": "Fetching {south} · {west} to {north} · {east} at "
              "{spacing_m} m.",
    },
    "task.fetch.slow": {
        "tr": "Bu adım internet bağlantısı gerektiren tek işlemdir ve bir"
              " süre alabilir.",
        "en": "The only thing here that uses the network. It can take a "
              "while.",
    },
    "task.fetch.got": {
        "tr": "{width_m} x {height_m} m, engebe {relief_m} m, pürüzlülük "
              "{roughness_m} m",
        "en": "{width_m} x {height_m} m, relief {relief_m} m, roughness "
              "{roughness_m} m",
    },
    "task.deliver.table": {
        "tr": "Tablo hesaplanıyor.",
        "en": "Running the table.",
    },
    "task.deliver.budget": {
        "tr": "Hata, bileşenlerine ayrıştırılıyor. Bu adım işlemin en "
              "yavaş kısmıdır.",
        "en": "Taking the error apart. This is the slow part.",
    },
    "task.deliver.wrote": {"tr": "{path} yazıldı", "en": "Wrote {path}"},
}


def say(key: str, language: str | None = None, **fields) -> str:
    """One built sentence, in the language asked for.

    Raises rather than falling back to the other language: a missing
    sentence is a half-translated page, and a page half in English is
    something nobody notices until somebody else does.
    """
    try:
        both = CATALOGUE[key]
    except KeyError:
        raise KeyError(
            "nothing to say for {!r}. Add it to CATALOGUE in both "
            "languages.".format(key)
        ) from None
    return both[chosen(language)].format(**fields)
